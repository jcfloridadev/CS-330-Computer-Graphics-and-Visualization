///////////////////////////////////////////////////////////////////////////////
// vertexShader.glsl
//
// This vertex shader processes vertex positions, texture coordinates, and
// surface normals for the 3D scene. For the Module Six lighting assignment,
// the normal transformation was updated so surface normals correctly follow
// the model's transformations, allowing lighting calculations to accurately
// represent the orientation of the rendered objects.
//
// Modified by: Justin Carlo Florida
///////////////////////////////////////////////////////////////////////////////

#version 410 core
layout (location = 0) in vec3 inVertexPosition;
layout (location = 1) in vec3 inVertexNormal;
layout (location = 2) in vec2 inTextureCoordinate;

out vec3 fragmentPosition;
out vec3 fragmentVertexNormal;
out vec2 fragmentTextureCoordinate;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
   fragmentPosition = vec3(model * vec4(inVertexPosition, 1.0));
   gl_Position = projection * view * model * vec4(inVertexPosition, 1.0f);

   // Transform the normal with the model matrix so lighting
   // follows the object's actual orientation in the scene.
   fragmentVertexNormal = mat3(transpose(inverse(model))) * inVertexNormal;

   fragmentTextureCoordinate = inTextureCoordinate;
}