///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// ================
// CS-330 Computational Graphics and Visualization
// Final Project: 3D House Scene
//
// This file manages the creation and rendering of the final 3D house scene.
// It applies transformations, textures, materials, and lighting to construct
// the house and surrounding environment using multiple primitive 3D shapes.
// The scene includes the house structure, garage, doors, windows, roof,
// chimneys, grass, walkways, trees, and background elements. Custom lighting
// and shader functionality are also used to improve the overall appearance
// and realism of the completed scene.
//
// Developer: Justin Carlo Florida
//
// Original framework:
// Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330 Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Initialize the texture collection.
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// Prevent loading more textures than the 16 available slots.
		if (m_loadedTextures >= 16)
		{
			std::cout << "Texture limit reached. Could not register: "
				<< filename << std::endl;

			glDeleteTextures(1, &textureID);
			return false;
		}

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

// ========================================================================================================================================================================================================================
// below is the load scene textures method that loads the textures used in the scene and binds them to the available OpenGL texture units.
// ========================================================================================================================================================================================================================

/***********************************************************
 * LoadSceneTextures()
 *
 * Loads the texture images used by the house scene and
 * binds them to the available OpenGL texture units.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// Load brick for the garage or exterior walls.
	CreateGLTexture(
		"../../Utilities/textures/brick1.jpg",
		"brick1");

	// Load the panel texture for the garage door.
	CreateGLTexture(
		"../../Utilities/textures/garagedoor.png",
		"garageDoor");

	// Load grass for both lawn sections.
	CreateGLTexture(
		"../../Utilities/textures/grass.jpg",
		"grass");

	// Load roof shingles for the garage roof.
	CreateGLTexture(
		"../../Utilities/textures/roof.jpg",
		"roof");

	// Load asphalt texture for the ground.
	CreateGLTexture(
		"../../Utilities/textures/asphalt.jpg",
		"asphalt");

	// Load the sky image for the background plane.
	CreateGLTexture(
		"../../Utilities/textures/sky.png",
		"sky");

	// Load the second floor texture image.
	CreateGLTexture(
		"../../Utilities/textures/secondfloor.jpg",
		"secondFloor");

	// Load texture for the door.
	CreateGLTexture(
		"../../Utilities/textures/doors2.png",
		"door2");

	// Load texture for the window.
	CreateGLTexture(
		"../../Utilities/textures/window.png",
		"window");

	// Load texture for the tree leaves.
	CreateGLTexture(
		"../../Utilities/textures/leaves.jpg",
		"leaves");

	// Load texture for the tree trunk.
	CreateGLTexture(
		"../../Utilities/textures/trunk.jpg",
		"trunk");

	// Load texture for the tree leaves1.
	CreateGLTexture(
		"../../Utilities/textures/leaves1.jpg",
		"leaves1");

	// Bind the loaded textures to OpenGL texture units.
	BindGLTextures();
}

/***********************************************************
 * DefineObjectMaterials()
 *
 * Defines material properties that control how the textured
 * objects react to ambient, diffuse, and specular lighting.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// Brick is mostly matte with very little reflection.
	OBJECT_MATERIAL brickMaterial;
	brickMaterial.ambientColor = glm::vec3(0.60f, 0.55f, 0.55f);
	brickMaterial.ambientStrength = 0.55f;
	brickMaterial.diffuseColor = glm::vec3(0.75f, 0.70f, 0.70f);
	brickMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	brickMaterial.shininess = 4.0f;
	brickMaterial.tag = "brick";
	m_objectMaterials.push_back(brickMaterial);

	// Second floor has a smooth surface with moderate reflection.
	OBJECT_MATERIAL secondFloorMaterial;
	secondFloorMaterial.ambientColor = glm::vec3(0.60f, 0.60f, 0.60f);
	secondFloorMaterial.ambientStrength = 0.55f;
	secondFloorMaterial.diffuseColor = glm::vec3(0.75f, 0.75f, 0.75f);
	secondFloorMaterial.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
	secondFloorMaterial.shininess = 12.0f;
	secondFloorMaterial.tag = "secondfloor";
	m_objectMaterials.push_back(secondFloorMaterial);

	// Roof shingles are rough and have little shine.
	OBJECT_MATERIAL roofMaterial;
	roofMaterial.ambientColor = glm::vec3(0.65f, 0.55f, 0.55f);
	roofMaterial.ambientStrength = 3.05f;
	roofMaterial.diffuseColor = glm::vec3(0.70f, 0.70f, 0.70f);
	roofMaterial.specularColor = glm::vec3(0.52f, 0.52f, 0.52f);
	roofMaterial.shininess = 4.0f;
	roofMaterial.tag = "roof";
	m_objectMaterials.push_back(roofMaterial);

	// Garage door has a slightly smoother surface.
	OBJECT_MATERIAL doorMaterial;
	doorMaterial.ambientColor = glm::vec3(0.60f, 0.50f, 0.50f);
	doorMaterial.ambientStrength = 0.55f;
	doorMaterial.diffuseColor = glm::vec3(0.75f, 0.75f, 0.75f);
	doorMaterial.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
	doorMaterial.shininess = 12.0f;
	doorMaterial.tag = "garageDoor";
	m_objectMaterials.push_back(doorMaterial);

	// Grass should remain soft and non-reflective.
	OBJECT_MATERIAL grassMaterial;
	grassMaterial.ambientColor = glm::vec3(0.25f, 0.30f, 0.25f);
	grassMaterial.ambientStrength = 2.30f;
	grassMaterial.diffuseColor = glm::vec3(0.70f, 0.75f, 0.70f);
	grassMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	grassMaterial.shininess = 2.0f;
	grassMaterial.tag = "grass";
	m_objectMaterials.push_back(grassMaterial);

	// Asphalt is rough with very little specular reflection.
	OBJECT_MATERIAL asphaltMaterial;
	asphaltMaterial.ambientColor = glm::vec3(0.25f, 0.25f, 0.25f);
	asphaltMaterial.ambientStrength = 2.30f;
	asphaltMaterial.diffuseColor = glm::vec3(0.70f, 0.70f, 0.70f);
	asphaltMaterial.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	asphaltMaterial.shininess = 2.0f;
	asphaltMaterial.tag = "asphalt";
	m_objectMaterials.push_back(asphaltMaterial);

	// Keep the sky easily visible without strong reflections.
	OBJECT_MATERIAL skyMaterial;
	skyMaterial.ambientColor = glm::vec3(0.60f, 0.60f, 0.60f);
	skyMaterial.ambientStrength = 2.50f;
	skyMaterial.diffuseColor = glm::vec3(1.00f, 1.00f, 1.00f);
	skyMaterial.specularColor = glm::vec3(0.0f, 0.0f, 0.0f);
	skyMaterial.shininess = 1.0f;
	skyMaterial.tag = "sky";
	m_objectMaterials.push_back(skyMaterial);
}

/***********************************************************
 * SetupSceneLights()
 *
 * Configures two soft light sources to illuminate the house
 * scene while maintaining natural depth and surface shading.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Primary daylight source above and toward the camera-left side.
	m_pShaderManager->setVec3Value("lightSources[0].position", -8.0f, 12.0f, 14.0f);

	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.12f, 0.12f, 0.12f);

	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.85f, 0.85f, 0.80f);

	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.30f, 0.30f, 0.28f);

	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);

	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.48f);


	// Secondary fill light prevents the opposite side from becoming too dark.
	m_pShaderManager->setVec3Value("lightSources[1].position", 8.0f, 7.0f, 12.0f);

	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.06f, 0.06f, 0.07f);

	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.45f, 0.47f, 0.50f);

	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.12f, 0.12f, 0.14f);

	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 24.0f);

	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.48f);

	// Enable Phong lighting calculations in the shader.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load and bind the textures used throughout the scene.
	LoadSceneTextures();

	// Define how each textured surface reacts to lighting.
	DefineObjectMaterials();

	// Configure the primary and secondary scene lights.
	SetupSceneLights();

	// Load the meshes used by the house scene.
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	// ========================================================================================================================================================================================================================
	// Draw the ground plane.
	// ========================================================================================================================================================================================================================

	// set the XYZ scale for the ground plane mesh
	scaleXYZ = glm::vec3(80.0f, 1.0f, 20.0f);

	// set the XYZ rotation for the ground plane mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the ground plane mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 5.0f);

	// set the transformations into memory to be used on the drawn ground plane mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the asphalt texture to the ground plane.
	SetShaderTexture("asphalt");
	SetTextureUVScale(20.0f, 20.0f);

	// Apply the asphalt material properties to the ground plane.
	SetShaderMaterial("asphalt");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	// ========================================================================================================================================================================================================================
	// Draw the walkway plane.
	// ========================================================================================================================================================================================================================

	// set the XYZ scale for the walkway plane mesh
	scaleXYZ = glm::vec3(1.0f, 1.0f, 2.5f);

	// set the XYZ rotation for the walkway plane mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the walkway plane mesh
	positionXYZ = glm::vec3(2.15f, 0.05f, 4.0f);

	// set the transformations into memory to be used on the drawn walkway plane mesh
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the asphalt texture to the walkway plane.
	SetShaderTexture("asphalt");
	SetTextureUVScale(20.0f, 20.0f);

	// Apply the asphalt material properties to the walkway plane.
	SetShaderMaterial("asphalt");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	// =========================================================================================================================================================================================================================
	// Draw the background.
	// =========================================================================================================================================================================================================================

	// Set background scale
	scaleXYZ = glm::vec3(200.0f, 10.0f, 100.0f);

	// Set background rotation
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Set background position
	positionXYZ = glm::vec3(0.0f, 20.0f, -16.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the sky texture to the background plane.
	SetShaderTexture("sky");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply the sky material properties to the background plane.
	SetShaderMaterial("sky");

	// Draw background
	m_basicMeshes->DrawPlaneMesh();

	//// =========================================================================================================================================================================================================================
	//// Draw the background above.
	//// =========================================================================================================================================================================================================================

	//// Set background scale
	//scaleXYZ = glm::vec3(200.0f, 10.0f, 100.0f);

	//// Set background rotation
	//XrotationDegrees = 0.0f;
	//YrotationDegrees = 0.0f;
	//ZrotationDegrees = 0.0f;

	//// Set background position
	//positionXYZ = glm::vec3(50.0f, 20.0f, -16.0f);

	//// Apply transformations
	//SetTransformations(
	//	scaleXYZ,
	//	XrotationDegrees,
	//	YrotationDegrees,
	//	ZrotationDegrees,
	//	positionXYZ);

	//// Apply the sky texture to the background plane.
	//SetShaderTexture("sky");
	//SetTextureUVScale(1.0f, 1.0f);

	//// Apply the sky material properties to the background plane.
	//SetShaderMaterial("sky");

	//// Draw background
	m_basicMeshes->DrawPlaneMesh();

	// =========================================================================================================================================================================================================================
	// Draw the background right.
	// =========================================================================================================================================================================================================================

	// Set background scale
	scaleXYZ = glm::vec3(200.0f, 10.0f, 100.0f);

	// Set background rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 95.0f;

	// Set background position
	positionXYZ = glm::vec3(50.0f, 20.0f, -16.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the sky texture to the background plane.
	SetShaderTexture("sky");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply the sky material properties to the background plane.
	SetShaderMaterial("sky");

	// Draw background
	m_basicMeshes->DrawPlaneMesh();

	// ========================================================================================================================================================================================================================
	// Draw the garage body.
	// ========================================================================================================================================================================================================================

	// Set garage body scale
	scaleXYZ = glm::vec3(6.0f, 3.5f, 6.0f);

	// Set garage body rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 1.0f;
	ZrotationDegrees = 0.0f;

	// Set garage body position
	positionXYZ = glm::vec3(-3.0f, 1.8f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the brick texture to the garage body.
	SetShaderTexture("brick1");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply the brick material properties to the garage body.
	SetShaderMaterial("brick");

	// Draw garage body.
	m_basicMeshes->DrawBoxMesh();

	// ========================================================================================================================================================================================================================
	// Draw the lower roof.
	// ========================================================================================================================================================================================================================

	// Set lower roof scale
	scaleXYZ = glm::vec3(6.0f, 6.0f, 2.0f);

	// Set lower roof rotation
	XrotationDegrees = -90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// Set lower roof position
	positionXYZ = glm::vec3(-3.00f, 4.55f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the lower roof texture to the lower roof.
	SetShaderTexture("roof");
	SetTextureUVScale(4.0f, 4.0f);

	// Apply the roof material properties to the lower roof.
	SetShaderMaterial("roof");

	// Draw lower roof
	m_basicMeshes->DrawPrismMesh();

	// ========================================================================================================================================================================================================================
	// Draw the upper roof.
	// ========================================================================================================================================================================================================================

	// Set upper roof scale
	scaleXYZ = glm::vec3(6.0f, 8.0f, 2.0f);

	// Set upper roof rotation
	XrotationDegrees = -90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// Set upper roof position
	positionXYZ = glm::vec3(3.50f, 8.55f, -1.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the upper roof texture to the upper roof.
	SetShaderTexture("roof");
	SetTextureUVScale(4.0f, 4.0f);

	// Apply the roof material properties to the upper roof.
	SetShaderMaterial("roof");

	// Draw upper roof
	m_basicMeshes->DrawPrismMesh();

	// ========================================================================================================================================================================================================================
	// Draw the side trim roof.
	// ========================================================================================================================================================================================================================

	// Set upper side trim scale
	scaleXYZ = glm::vec3(6.0f, 0.05f, 2.0f);

	// Set upper side trim rotation
	XrotationDegrees = -90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// Set upper side trim position
	positionXYZ = glm::vec3(-6.00f, 4.55f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the upper roof texture to the upper roof.
	SetShaderTexture("secondFloor");
	SetTextureUVScale(4.0f, 4.0f);

	// Apply the roof material properties to the upper roof.
	SetShaderMaterial("roof");

	// Draw upper roof
	m_basicMeshes->DrawPrismMesh();

	// ========================================================================================================================================================================================================================
	// Draw the garage roof2.
	// ========================================================================================================================================================================================================================

	// Set garage roof2 scale
	scaleXYZ = glm::vec3(7.0f, 8.5f, 2.0f);

	// Set garage roof2 rotation
	XrotationDegrees = -90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 90.0f;

	// Set garage roof2 position
	positionXYZ = glm::vec3(3.25f, 4.55f, -0.5f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the roof texture to the garage roof.
	SetShaderTexture("roof");
	SetTextureUVScale(4.0f, 4.0f);

	// Apply the roof material properties to the garage roof.
	SetShaderMaterial("roof");

	// Draw garage roof
	m_basicMeshes->DrawPrismMesh();

	// ================================================================================================================================================================================================================================
	// Draw the garage door.
	// ================================================================================================================================================================================================================================

	// Set garage door scale
	scaleXYZ = glm::vec3(4.0f, 3.0f, 0.20f);

	// Set garage door rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 1.0f;
	ZrotationDegrees = 0.0f;

	// Set garage door position
	positionXYZ = glm::vec3(-3.0f, 1.5f, 2.92f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the garage door texture.
	SetShaderTexture("garageDoor");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply the garage door material properties.
	SetShaderMaterial("garageDoor");


	// Draw garage door
	m_basicMeshes->DrawBoxMesh();

	// ===================================================================================================================================================================================================================================
	// Draw the 1left grass.
	// ===================================================================================================================================================================================================================================

	// Set 1left grass scale
	scaleXYZ = glm::vec3(6.0f, 1.0f, 6.0f);

	// Set left grass rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Set 1left grass position
	positionXYZ = glm::vec3(-11.0f, 0.02f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply and tile the grass texture across the first lawn section.
	SetShaderTexture("grass");
	SetTextureUVScale(8.0f, 8.0f);

	// Apply the grass material properties to the first lawn section.
	SetShaderMaterial("grass");

	// Draw 1left grass
	m_basicMeshes->DrawPlaneMesh();

	// ===================================================================================================================================================================================================================================
	// Draw the 1right grass.
	// ===================================================================================================================================================================================================================================

	// Set 1right grass scale
	scaleXYZ = glm::vec3(6.0f, 1.0f, 6.0f);

	// Set right grass rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Set 1right grass position
	positionXYZ = glm::vec3(5.0f, 0.02f, 0.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply and tile the grass texture across the first lawn section.
	SetShaderTexture("grass");
	SetTextureUVScale(8.0f, 8.0f);

	// Apply the grass material properties to the first lawn section.
	SetShaderMaterial("grass");

	// Draw 1left grass
	m_basicMeshes->DrawPlaneMesh();

	// ===================================================================================================================================================================================================================================
	// Draw the 2left grass.
	// ===================================================================================================================================================================================================================================

	// Set 2left grass scale
	scaleXYZ = glm::vec3(5.75f, 1.0f, 1.15f);

	// Set 2left grass rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Set 2left grass position
	positionXYZ = glm::vec3(-11.0f, 0.02f, 8.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply and tile the grass texture across the second lawn section.
	SetShaderTexture("grass");
	SetTextureUVScale(10.0f, 10.0f);

	// Apply the grass material properties to the second lawn section.
	SetShaderMaterial("grass");

	// Draw left grass
	m_basicMeshes->DrawPlaneMesh();

	// ===================================================================================================================================================================================================================================
	// Draw the 2right grass.
	// ===================================================================================================================================================================================================================================

	// Set 2right grass scale
	scaleXYZ = glm::vec3(5.75f, 1.0f, 1.15f);

	// Set 2right grass rotation
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Set 2right grass position
	positionXYZ = glm::vec3(5.0f, 0.02f, 8.0f);

	// Apply transformations
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply and tile the grass texture across the second lawn section.
	SetShaderTexture("grass");
	SetTextureUVScale(10.0f, 10.0f);

	// Apply the grass material properties to the second lawn section.
	SetShaderMaterial("grass");

	// Draw left grass
	m_basicMeshes->DrawPlaneMesh();

	// ===========================================================================
	// Draw the lower right section of the house.
	// ===========================================================================

	// Set lower house scale.
	scaleXYZ = glm::vec3(8.0f, 3.5f, 6.0f);

	// Set lower house rotation.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the lower house section to the right of the garage.
	positionXYZ = glm::vec3(3.5f, 1.8f, -1.0f);

	// Apply transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Reuse the brick texture for the lower house section.
	SetShaderTexture("brick1");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply the brick material.
	SetShaderMaterial("brick");

	// Draw the lower house body.
	m_basicMeshes->DrawBoxMesh();

	// ===========================================================================
	// Draw the upper right section of the house.
	// ===========================================================================

	// Set upper house scale.
	scaleXYZ = glm::vec3(8.0f, 4.0f, 6.0f);

	// Set upper house rotation.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the upper house section to the right of the garage.
	positionXYZ = glm::vec3(3.5f, 5.55f, -1.0f);

	// Apply transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Reuse the brick texture for the lower house section.
	SetShaderTexture("secondFloor");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply the brick material.
	SetShaderMaterial("brick");

	// Draw the lower house body.
	m_basicMeshes->DrawBoxMesh();

	// ===========================================================================
	// Draw the front door.
	// ===========================================================================

	// Set front door1 scale.
	scaleXYZ = glm::vec3(1.75f, 2.8f, 0.15f);

	// Set front door rotation.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the door on the front of the lower house.
	positionXYZ = glm::vec3(2.15f, 1.4f, 1.97f);

	// Apply transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the door texture for the front door.
	SetShaderTexture("door2");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply an existing material for lighting.
	SetShaderMaterial("brick");

	// Draw the front door.
	m_basicMeshes->DrawBoxMesh();

	// ===========================================================================
	// Draw the front window.
	// ===========================================================================

	// Set front window scale.
	scaleXYZ = glm::vec3(2.5f, 1.8f, 0.12f);

	// Set front window rotation.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the window to the right of the front door.
	positionXYZ = glm::vec3(5.5f, 2.0f, 1.97f);

	// Apply transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the window texture for the front window.
	SetShaderTexture("window");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply an existing material for lighting.
	SetShaderMaterial("brick");

	// Draw the front window.
	m_basicMeshes->DrawBoxMesh();

	// ===========================================================================
	// Draw the top right window.
	// ===========================================================================

	// Set front window scale.
	scaleXYZ = glm::vec3(2.5f, 1.8f, 0.12f);

	// Set front window rotation.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the window to the right of the front door.
	positionXYZ = glm::vec3(5.5f, 6.0f, 1.97f);

	// Apply transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the window texture for the front window.
	SetShaderTexture("window");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply an existing material for lighting.
	SetShaderMaterial("brick");

	// Draw the front window.
	m_basicMeshes->DrawBoxMesh();

	// ===========================================================================
	// Draw the top left window.
	// ===========================================================================

	// Set front window scale.
	scaleXYZ = glm::vec3(2.5f, 1.8f, 0.12f);

	// Set front window rotation.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the window to the right of the front door.
	positionXYZ = glm::vec3(1.5f, 6.0f, 1.97f);

	// Apply transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the window texture for the front window.
	SetShaderTexture("window");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply an existing material for lighting.
	SetShaderMaterial("brick");

	// Draw the front window.
	m_basicMeshes->DrawBoxMesh();

	// ===========================================================================
	// Draw the top garage window.
	// ===========================================================================

	// Set front window scale.
	scaleXYZ = glm::vec3(2.0f, 1.0f, 0.12f);

	// Set front window rotation.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 0.0f;

	// Position the window to the right of the front door.
	positionXYZ = glm::vec3(-0.47f, 6.5f, -0.5f);

	// Apply transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the window texture for the front window.
	SetShaderTexture("window");
	SetTextureUVScale(1.0f, 1.0f);

	// Apply an existing material for lighting.
	SetShaderMaterial("brick");

	// Draw the front window.
	m_basicMeshes->DrawBoxMesh();

	// ===========================================================================
	// Draw the large tree behind the house.
	// ===========================================================================

	// Tree trunk.
	scaleXYZ = glm::vec3(0.55f, 5.0f, 0.55f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the tree behind and to the right of the house.
	positionXYZ = glm::vec3(10.0f, 0.0f, -5.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the trunk texture for the tree trunk.
	SetShaderTexture("trunk");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("brick");

	m_basicMeshes->DrawCylinderMesh();


	// Tree foliage.
	scaleXYZ = glm::vec3(2.0f, 2.5f, 2.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(9.0f, 11.25f, -5.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the leaves texture for the tree foliage.
	SetShaderTexture("leaves");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("grass");

	m_basicMeshes->DrawSphereMesh();

	// Tree foliage1.
	scaleXYZ = glm::vec3(2.0f, 2.5f, 2.0f);

	XrotationDegrees = 95.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(12.0f, 8.25f, -5.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the leaves texture for the tree foliage.
	SetShaderTexture("leaves");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("grass");

	m_basicMeshes->DrawSphereMesh();

	// Tree foliage2.
	scaleXYZ = glm::vec3(3.0f, 3.5f, 3.0f);

	XrotationDegrees = 95.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(10.0f, 7.25f, -5.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the leaves texture for the tree foliage.
	SetShaderTexture("leaves");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("grass");

	m_basicMeshes->DrawSphereMesh();

	// Tree foliage3.
	scaleXYZ = glm::vec3(2.0f, 3.5f, 2.5f);

	XrotationDegrees = 95.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(12.5f, 10.25f, -5.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the leaves texture for the tree foliage.
	SetShaderTexture("leaves");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("grass");

	m_basicMeshes->DrawSphereMesh();

	// ===========================================================================
	// Draw the tree infont of the house.
	// ===========================================================================

	// Tree trunk.
	scaleXYZ = glm::vec3(0.25f, 5.0f, 0.25f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the tree behind and to the right of the house.
	positionXYZ = glm::vec3(8.0f, 0.0f, 4.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the leaves texture for the tree trunk.
	SetShaderTexture("trunk");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("brick");

	m_basicMeshes->DrawCylinderMesh();


	// Tree foliage.
	scaleXYZ = glm::vec3(1.5f, 1.0f, 1.5f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(7.0f, 5.5f, 4.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the leaves texture for the tree foliage.
	SetShaderTexture("leaves1");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("grass");

	m_basicMeshes->DrawSphereMesh();

	// Tree foliage2.
	scaleXYZ = glm::vec3(1.5f, 1.0f, 1.5f);

	XrotationDegrees = 65.0f;
	YrotationDegrees = 95.0f;
	ZrotationDegrees = 12.0f;

	positionXYZ = glm::vec3(9.0f, 5.5f, 4.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the leaves texture for the tree foliage.
	SetShaderTexture("leaves1");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("grass");

	m_basicMeshes->DrawSphereMesh();

	// Tree foliage3.
	scaleXYZ = glm::vec3(2.5f, 2.0f, 1.5f);

	XrotationDegrees = 90.0f;
	YrotationDegrees = 45.0f;
	ZrotationDegrees = 90.0f;

	positionXYZ = glm::vec3(8.0f, 6.5f, 4.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Use the leaves texture for the tree foliage.
	SetShaderTexture("leaves1");
	SetTextureUVScale(1.0f, 1.0f);

	SetShaderMaterial("grass");

	m_basicMeshes->DrawSphereMesh();

	// ===========================================================================
	// Draw the chimney on the upper roof.
	// ===========================================================================

	scaleXYZ = glm::vec3(0.8f, 1.8f, 0.8f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the chimney toward the right side of the upper roof.
	positionXYZ = glm::vec3(6.0f, 9.7f, -1.2f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Reuse the brick texture for the chimney.
	SetShaderTexture("brick1");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("brick");

	m_basicMeshes->DrawBoxMesh();

	// ===========================================================================
	// Draw the tall chimney on the left side of the garage.
	// ===========================================================================

// Set the chimney scale.
	scaleXYZ = glm::vec3(0.8f, 5.8f, 1.2f);

	// Keep the chimney upright.
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the chimney against the outside-left wall of the garage.
	positionXYZ = glm::vec3(-5.90f, 2.9f, -1.5f);

	// Apply transformations.
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the brick texture to match the exterior.
	SetShaderTexture("brick1");
	SetTextureUVScale(1.0f, 2.0f);

	// Apply the brick material properties.
	SetShaderMaterial("brick");

	// Draw the tall chimney.
	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
}
