///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// ===============
// CS-330 Computational Graphics and Visualization
// Final Project: Camera Navigation and Projection Controls
//
// This file manages the camera, display window, projection settings, and user
// input for navigating the 3D scene. It supports keyboard movement, mouse
// orientation, scroll-controlled travel speed, and perspective or orthographic
// projection modes.
//
// Original framework created by Brian Battersby, SNHU Instructor.
// Modified by: Justin Carlo Florida
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// controls the camera travel speed
	float gMovementSpeed = 3.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(-8.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(1.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	//glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// this callback is used to receive mouse wheel scrolling events
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Wheel_Callback);

	// enable blending to support transparent rendering.
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// Record the initial mouse position when camera control begins.
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
		return;
	}

	// Calculate movement since the previous mouse event.
	float xOffset =
		static_cast<float>(xMousePos) - gLastX;

	float yOffset =
		gLastY - static_cast<float>(yMousePos);

	// Store this position for the next event.
	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	// Rotate the camera based only on the mouse movement.
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Wheel_Callback()
 *
 *  This method is automatically called whenever the mouse
 *  wheel is scrolled. It adjusts the camera movement speed.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Wheel_Callback(
	GLFWwindow* window,
	double xOffset,
	double yOffset)
{
	// Increase or decrease the camera movement speed
	gMovementSpeed += static_cast<float>(yOffset) * 0.5f;

	// Prevent the movement speed from becoming too slow
	if (gMovementSpeed < 0.5f)
	{
		gMovementSpeed = 0.5f;
	}

	// Prevent the movement speed from becoming excessively fast
	if (gMovementSpeed > 10.0f)
	{
		gMovementSpeed = 10.0f;
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// if the camera object is null, then exit this method
	if (NULL == g_pCamera)
	{
		return;
	}

	// apply the mouse-wheel speed setting to camera movement
	float adjustedDeltaTime = gDeltaTime * gMovementSpeed;

	// process camera movement forward and backward
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, adjustedDeltaTime);
	}

	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, adjustedDeltaTime);
	}

	// process camera movement left and right
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, adjustedDeltaTime);
	}

	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, adjustedDeltaTime);
	}

	// move the camera upward
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position.y += adjustedDeltaTime;
	}

	// move the camera downward
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position.y -= adjustedDeltaTime;
	}

	static bool fKeyPreviouslyPressed = false;
	static bool rKeyPreviouslyPressed = false;

	bool fKeyPressed =
		glfwGetKey(m_pWindow, GLFW_KEY_F) == GLFW_PRESS;

	bool rKeyPressed =
		glfwGetKey(m_pWindow, GLFW_KEY_R) == GLFW_PRESS;

	// Capture only once when F is first pressed
	if (fKeyPressed && !fKeyPreviouslyPressed)
	{
		glfwSetInputMode(m_pWindow, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

		gFirstMouse = true;
	}

	// Release only once when R is first pressed
	if (rKeyPressed && !rKeyPreviouslyPressed)
	{
		glfwSetInputMode(m_pWindow, GLFW_CURSOR, GLFW_CURSOR_NORMAL);

		gFirstMouse = true;
	}

	// Switch to perspective projection
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}

	// Switch to orthographic projection
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;

		// Position the camera directly in front of the scene.
		g_pCamera->Position = glm::vec3(0.0f, 4.0f, 15.0f);
		g_pCamera->Front = glm::vec3(0.0f, 0.0f, -1.0f);
		g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	}

	fKeyPreviouslyPressed = fKeyPressed;
	rKeyPreviouslyPressed = rKeyPressed;
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	// Calculate the elapsed time between the current and previous frame.
	// This keeps camera movement smooth and independent of frame rate.
	float currentFrame = static_cast<float>(glfwGetTime());

	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// Calculate the width-to-height ratio of the display window
	float aspectRatio =
		static_cast<float>(WINDOW_WIDTH) /
		static_cast<float>(WINDOW_HEIGHT);

	// Select the projection matrix based on the current view mode
	if (bOrthographicProjection)
	{
		// Orthographic projection displays the scene without perspective depth
		float orthoHeight = 10.0f;
		float orthoWidth = orthoHeight * aspectRatio;

		projection = glm::ortho(
			-orthoWidth,
			orthoWidth,
			-orthoHeight,
			orthoHeight,
			0.1f,
			100.0f);
	}
	else
	{
		// Perspective projection creates a natural 3D depth appearance
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			aspectRatio,
			0.1f,
			100.0f);
	}

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}