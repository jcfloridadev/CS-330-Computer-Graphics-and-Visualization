///////////////////////////////////////////////////////////////////////////////
// ViewManager.h
// =============
// CS-330 Computational Graphics and Visualization
// Final Project: Camera Navigation and Projection Controls
//
// This file declares the ViewManager class and the functions used to create
// the OpenGL display window, process keyboard and mouse input, adjust camera
// movement speed, and prepare perspective or orthographic scene views.
//
// Original framework created by Brian Battersby, SNHU Instructor.
// Modified by: Justin Carlo Florida
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
	// constructor
	ViewManager(
		ShaderManager* pShaderManager);
	// destructor
	~ViewManager();

	// mouse position callback for mouse interaction with the 3D scene
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);
	// mouse scroll callback for adjusting camera movement speed
	static void Mouse_Scroll_Wheel_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// active OpenGL display window
	GLFWwindow* m_pWindow;

	// process keyboard events for interaction with the 3D scene
	void ProcessKeyboardEvents();

public:
	// create the initial OpenGL display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);
	
	// prepare the conversion from 3D object display to 2D scene display
	void PrepareSceneView();
};